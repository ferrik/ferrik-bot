# Ferrik Bot Application Package
